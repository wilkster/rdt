Windows help format documentation file twapi.chm is included
in this release.

Documentation is also available at http://twapi.magicsplat.com

For installation instructions, see the Installation topic
in the documentation.

The software is covered by a BSD-style license.
See the file LICENSE for details.
